// Project: https://github.com/vueComponent/ant-design-vue
// Definitions by: akki-jat <https://github.com/akki-jat>
// Definitions: https://github.com/vueComponent/ant-design-vue/types

export * from './ant-design-vue';

import * as Antd from './ant-design-vue';
export default Antd;
